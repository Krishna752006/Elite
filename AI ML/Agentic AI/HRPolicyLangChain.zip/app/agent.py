import os
import re
from typing import List, Dict
from dotenv import load_dotenv
from pymongo import MongoClient
from datetime import datetime

from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain.tools import tool
from langchain_community.vectorstores import FAISS
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.messages import HumanMessage, ToolMessage

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
MONGO_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")

client = MongoClient(MONGO_URI)
db = client["hr_agent"]

employees = db["employees"]
leave_requests = db["leave_requests"]
reimbursement_requests = db["reimbursement_requests"]
audit_logs = db["audit_logs"]

# -------------------------
# VECTOR STORE
# -------------------------
def build_vectorstore():
    loader = PyPDFLoader("policy/hr_policy.pdf")
    docs = loader.load()

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=800,
        chunk_overlap=100
    )

    chunks = splitter.split_documents(docs)
    embeddings = OpenAIEmbeddings()

    return FAISS.from_documents(chunks, embeddings)


vectorstore = build_vectorstore()
retriever = vectorstore.as_retriever(search_kwargs={"k": 3})

# -------------------------
# HELPERS
# -------------------------
def now():
    return datetime.utcnow().isoformat()


def get_employee(emp_id):
    print("GET Employee Called")
    return employees.find_one({"employee_id": emp_id}, {"_id": 0})


# -------------------------
# TOOLS (FIXED WITH DOCSTRINGS)
# -------------------------

@tool
def search_policy(query: str) -> str:
    """Search HR policy documents to find relevant rules."""
    docs = retriever.invoke(query)
    print("Search Policy Called")
    return "\n\n".join([d.page_content for d in docs])


@tool
def check_leave_balance(employee_id: str) -> str:
    """Get current leave balance of an employee."""
    emp = get_employee(employee_id)
    print("Check Leave Balance Called")
    if not emp:
        return "Employee not found"
    return str(emp["leave_balance"])


@tool
def apply_leave(employee_id: str, days: int) -> str:
    """Apply leave for an employee after checking balance."""
    print("Apply Leave Called")
    emp = get_employee(employee_id)
    if not emp:
        return "Employee not found"

    if emp["leave_balance"] < days:
        return "Insufficient balance"

    employees.update_one(
        {"employee_id": employee_id},
        {"$inc": {"leave_balance": -days}}
    )

    leave_requests.insert_one({
        "employee_id": employee_id,
        "days": days,
        "created_at": now()
    })

    audit_logs.insert_one({
        "employee_id": employee_id,
        "action": "leave",
        "days": days,
        "created_at": now()
    })

    return f"Leave approved. Remaining: {emp['leave_balance'] - days}"


@tool
def check_reimbursement(employee_id: str) -> str:
    """Check reimbursement usage for an employee."""
    print("Check Reimbursement Called")
    emp = get_employee(employee_id)
    if not emp:
        return "Employee not found"

    used = emp.get("reimbursement_used_this_month", 0)
    return f"Used: {used}, Remaining: {5000 - used}"


@tool
def submit_reimbursement(employee_id: str, amount: int) -> str:
    """Submit a reimbursement request if within allowed limits."""
    emp = get_employee(employee_id)
    print("Submit Reimbursement Called")
    if not emp:
        return "Employee not found"

    used = emp.get("reimbursement_used_this_month", 0)

    if used + amount > 5000:
        return "Exceeds monthly limit"

    employees.update_one(
        {"employee_id": employee_id},
        {"$inc": {"reimbursement_used_this_month": amount}}
    )

    reimbursement_requests.insert_one({
        "employee_id": employee_id,
        "amount": amount,
        "created_at": now()
    })

    return "Reimbursement submitted"


# -------------------------
# LLM + TOOL BINDING
# -------------------------
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

tools = [
    search_policy,
    check_leave_balance,
    apply_leave,
    check_reimbursement,
    submit_reimbursement
]

llm_with_tools = llm.bind_tools(tools)

# -------------------------
# MEMORY
# -------------------------
SESSION_STORE: Dict[str, List] = {}


def get_history(session_id):
    return SESSION_STORE.setdefault(session_id, [])

def extract_days(text: str) -> int:
    match = re.search(r'(\d+)', text)
    if match:
        return int(match.group(1))

def extract_amount(text: str) -> int:
    numbers = re.findall(r'\d+', text)

    if not numbers:
        return 0

    # pick the largest number (assumption: amount > days)
    return max(map(int, numbers))

# -------------------------
# RUN AGENT
# -------------------------
def run_agent(session_id: str, user_input: str):
    try:
        history = get_history(session_id)
        user_text = user_input.lower()

        # -------------------------
        # 🚀 APPLY LEAVE (FIXED)
        # -------------------------
        if "apply leave" in user_text or "leave for" in user_text:
            employee_id = "E001"
            # ✅ Extract days dynamically
            days = extract_days(user_text)

            tool_result = apply_leave.invoke({
                "employee_id": employee_id,
                "days": days
            })

            messages = [
                HumanMessage(content=user_input),
                HumanMessage(content=f"Tool result: {tool_result}")
            ]

            final = llm.invoke(messages)

            return final.content or str(tool_result)

        # -------------------------
        # 🚀 CHECK LEAVE BALANCE
        # -------------------------
        elif "leave" in user_text and (
            "balance" in user_text
            or "remaining" in user_text
            or "left" in user_text
            or "available" in user_text
        ):
            employee_id = "E001"

            tool_result = check_leave_balance.invoke({
                "employee_id": employee_id
            })

            return f"Employee {employee_id} currently has {tool_result} days of leave remaining."

        # -------------------------
        # 🚀 REIMBURSEMENT
        # -------------------------
        elif "reimbursement" in user_text:
            print("Reimbursement called")
            employee_id = "E001"

            amount = extract_amount(user_input)  # 🔥 IMPORTANT: use original input

            print("DEBUG AMOUNT:", amount)

            tool_result = submit_reimbursement.invoke({
                "employee_id": employee_id,
                "amount": amount
            })

            return tool_result

        # -------------------------
        # 🧠 FALLBACK → LLM
        # -------------------------
        messages = history + [HumanMessage(content=user_input)]
        response = llm.invoke(messages)

        history.append(HumanMessage(content=user_input))
        history.append(response)

        return response.content or "No response generated."

    except Exception as e:
        print("ERROR:", str(e))
        return f"Internal error: {str(e)}"