from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017")
db = client["hr_agent"]

db.employees.delete_many({})

db.employees.insert_one({
    "employee_id": "E001",
    "name": "Rahul",
    "leave_balance": 8,
    "reimbursement_used_this_month": 2000
})

print("Seeded successfully")