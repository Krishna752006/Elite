from fastapi import FastAPI
from pydantic import BaseModel
from app.agent import run_agent

app = FastAPI()


class ChatRequest(BaseModel):
    session_id: str
    message: str


@app.post("/chat")
def chat(req: ChatRequest):
    return {"response": run_agent(req.session_id, req.message)}