# Agentic HR System (Modern LangChain)

## Setup
pip install -r requirements.txt

## Run MongoDB
docker run -d -p 27017:27017 mongo

## Seed
python -m app.seed

## Run API
uvicorn app.api:app --reload

## Test
http://127.0.0.1:8000/docs
