import { encodeCursor, decodeCursor } from './cursor.js';

export function parseOffsetPagination(query) {
  //WRITE YOUR CODE HERE
}

export function parseCursorPagination(query) {
  //WRITE YOUR CODE HERE
}

export function buildNextCursorFromDocs(docs) {
  //WRITE YOUR CODE HERE
}
