export function buildEtag({ prefix, id, updatedAt }) {
  const ts = updatedAt instanceof Date ? updatedAt.getTime() : new Date(updatedAt).getTime();
  return `"${prefix}-${id}-${ts}"`;
}

export function handleIfNoneMatch(req, res, currentEtag) {
  //WRITE YOUR CODE
}

export function requireIfMatch(req, currentEtag) {
  //WRITE YOUR CODE
}
