import express from 'express';
import mongoose from 'mongoose';

import { Doctor } from '../models/Doctor.js';
import { Slot } from '../models/Slot.js';
import { parseOffsetPagination, parseCursorPagination, buildNextCursorFromDocs } from '../utils/pagination.js';
import { buildEtag, handleIfNoneMatch, requireIfMatch } from '../utils/etag.js';
import { encodeCursor } from '../utils/cursor.js';
import { httpError } from '../utils/httpErrors.js';
import { writeAudit } from '../services/auditService.js';

export const doctorsRouter = express.Router();

// GET /doctors?city=&specialty=&page=&limit=
// GET /doctors?mode=cursor&cursor=&limit=
doctorsRouter.get('/', async (req, res, next) => {
  //WRITE YOUR CODE HERE
});

// GET /doctors/:id  (ETag + If-None-Match)
doctorsRouter.get('/:id', async (req, res, next) => {
  //WRITE YOUR CODE HERE
});

// PUT /doctors/:id  (If-Match required)
doctorsRouter.put('/:id', async (req, res, next) => {
  //WRITE YOUR CODE HERE
});

// GET /doctors/:id/availability?date=YYYY-MM-DD&mode=offset&page=1&limit=10
// GET /doctors/:id/availability?date=YYYY-MM-DD&mode=cursor&cursor=&limit=10
// Returns AVAILABLE slots for that date.
doctorsRouter.get('/:id/availability', async (req, res, next) => {
  //WRITE YOUR CODE HERE
});
